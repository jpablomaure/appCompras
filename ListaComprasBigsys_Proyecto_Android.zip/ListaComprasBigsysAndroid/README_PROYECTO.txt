LISTA COMPRAS BIGSYS - Android
Versión 1.0.1

Incluye el catálogo precios.txt suministrado por el usuario.
Muestra Lista 1 y Lista 3 por artículo y ambos totales.
Permite importar futuros TXT de Bigsys desde el teléfono.

CORRECCIÓN v1.0.1:
- Evita conflicto de clases Kotlin duplicadas entre kotlin-stdlib 1.8.22
  y kotlin-stdlib-jdk7/jdk8 1.6.21 durante la compilación en GitHub Actions.

Para compilar por GitHub, subir este ZIP con el nombre exacto:
ListaComprasBigsys_Proyecto_Android.zip
El workflow del repositorio lo descomprime y genera el APK.
