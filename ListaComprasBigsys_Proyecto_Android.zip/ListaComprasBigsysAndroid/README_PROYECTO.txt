LISTA DE COMPRAS BIGSYS - Android v1.2.0

Funciones principales:
- Escaneo de códigos de barras dentro de la misma pantalla, con orientación vertical fija.
- Lista 1 y Lista 3 por artículo, subtotales y totales finales.
- Descuento final porcentual sobre la compra.
- Importación/vinculación de TXT desde almacenamiento local, Google Drive o Dropbox mediante el selector de Android.
- Sincronización periódica del archivo vinculado mientras la app está abierta.
- Lectura de la columna Oferta del TXT (columna 7).
- Formatos aceptados de oferta: "10% x3", "4.42% x10" y también "10% por 3".
- La oferta se activa al alcanzar la cantidad indicada y aplica el porcentaje a todas las unidades de ese artículo.
- Si la cantidad vuelve a quedar por debajo del mínimo, la oferta deja de aplicarse automáticamente.
- Muestra oferta activa, unidades faltantes y ahorro por Lista 1 y Lista 3.
- El descuento final general se aplica después de los descuentos por cantidad.

Estructura esperada del TXT:
3 Codigo
4 Descripcion del artículo
5 Lista 1
6 Lista 3
7 Oferta
18 Barras

El ZIP está preparado para el mismo workflow de GitHub que compila ListaComprasBigsys_Proyecto_Android.zip.
