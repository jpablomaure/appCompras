LISTA COMPRAS BIGSYS - PROYECTO ANDROID
Este ZIP se sube directamente al repositorio GitHub que ya tenga instalado el workflow compilar-apk.yml.
No descomprimir en GitHub. El workflow lo descomprime automáticamente.
