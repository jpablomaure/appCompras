package com.bigsys.listacompras;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.Holder> {
    public interface Listener {
        void onDelta(Product product, int delta);
        void onRemove(Product product);
    }

    public static class Row {
        public final Product product;
        public final int quantity;
        public Row(Product product, int quantity) {
            this.product = product;
            this.quantity = quantity;
        }
    }

    private final List<Row> rows = new ArrayList<>();
    private final Listener listener;

    public CartAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setRows(List<Row> newRows) {
        rows.clear();
        rows.addAll(newRows);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        Row row = rows.get(position);
        Product p = row.product;
        int q = row.quantity;

        h.descripcion.setText(p.descripcion);
        h.codigo.setText("Código: " + p.codigo + "   Barras: " + p.barras);
        h.cantidad.setText(String.valueOf(q));
        h.precio1.setText("Lista 1: " + Money.format(p.lista1));
        h.precio3.setText("Lista 3: " + Money.format(p.lista3));

        BigDecimal total1 = p.totalLinea(p.lista1, q);
        BigDecimal total3 = p.totalLinea(p.lista3, q);
        h.sub1.setText("L1: " + Money.format(total1));
        h.sub3.setText("L3: " + Money.format(total3));

        if (p.tieneOferta()) {
            h.oferta.setVisibility(View.VISIBLE);
            if (p.ofertaActiva(q)) {
                BigDecimal ah1 = p.ahorroOferta(p.lista1, q);
                BigDecimal ah3 = p.ahorroOferta(p.lista3, q);
                h.oferta.setText("OFERTA ACTIVA · " + p.etiquetaOferta()
                        + " · Ahorrás L1 " + Money.format(ah1)
                        + " · L3 " + Money.format(ah3));
            } else {
                int faltan = Math.max(0, p.ofertaCantidadMinima - q);
                h.oferta.setText("Oferta " + p.etiquetaOferta()
                        + " · faltan " + faltan + (faltan == 1 ? " unidad" : " unidades"));
            }
        } else {
            h.oferta.setVisibility(View.GONE);
            h.oferta.setText("");
        }

        h.mas.setOnClickListener(v -> listener.onDelta(p, 1));
        h.menos.setOnClickListener(v -> listener.onDelta(p, -1));
        h.eliminar.setOnClickListener(v -> listener.onRemove(p));
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView descripcion, codigo, cantidad, precio1, precio3, sub1, sub3, oferta;
        Button mas, menos, eliminar;

        Holder(View v) {
            super(v);
            descripcion = v.findViewById(R.id.txtDescripcion);
            codigo = v.findViewById(R.id.txtCodigo);
            cantidad = v.findViewById(R.id.txtCantidad);
            precio1 = v.findViewById(R.id.txtPrecioLista1);
            precio3 = v.findViewById(R.id.txtPrecioLista3);
            sub1 = v.findViewById(R.id.txtSubtotal1);
            sub3 = v.findViewById(R.id.txtSubtotal3);
            oferta = v.findViewById(R.id.txtOferta);
            mas = v.findViewById(R.id.btnMas);
            menos = v.findViewById(R.id.btnMenos);
            eliminar = v.findViewById(R.id.btnEliminar);
        }
    }
}
