package com.bigsys.listacompras;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements CartAdapter.Listener {
    private static final String INTERNAL_CATALOG = "catalogo_bigsys.txt";
    private static final String TEMP_CATALOG = "catalogo_bigsys.tmp";
    private static final String PREFS = "lista_compras_prefs";
    private static final String PREF_CART = "cart_json";
    private static final String PREF_FILE_NAME = "catalog_name";
    private static final String PREF_LINKED_URI = "linked_catalog_uri";
    private static final String PREF_LINKED_NAME = "linked_catalog_name";
    private static final String PREF_LINKED_SIGNATURE = "linked_catalog_signature";
    private static final String PREF_LAST_SYNC = "linked_catalog_last_sync";
    private static final String PREF_FINAL_DISCOUNT = "final_discount_percent";
    private static final long AUTO_SYNC_INTERVAL_MS = 5L * 60L * 1000L;

    private final Map<String, Product> byCode = new LinkedHashMap<>();
    private final Map<String, List<Product>> byBarcode = new LinkedHashMap<>();
    private final Map<String, Integer> cart = new LinkedHashMap<>();

    private TextView txtCatalogo, txtEstado, txtUnidades, txtSubtotal1, txtSubtotal3, txtTotal1, txtTotal3, txtSync, txtAhorroOfertas;
    private EditText edtBuscar, edtDescuento;
    private CartAdapter adapter;
    private SharedPreferences prefs;
    private LinearLayout scannerPanel;
    private DecoratedBarcodeView barcodeView;
    private boolean scannerRunning = false;
    private boolean scannerBusy = false;
    private String lastScannedBarcode = "";
    private long lastScanAt = 0L;
    private boolean syncing = false;
    private ToneGenerator scanTone;

    private final Handler autoSyncHandler = new Handler(Looper.getMainLooper());
    private final Runnable autoSyncRunnable = new Runnable() {
        @Override public void run() {
            syncLinkedCatalog(false);
            autoSyncHandler.postDelayed(this, AUTO_SYNC_INTERVAL_MS);
        }
    };

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) showInlineScanner();
                else showStatus("No se concedió permiso para usar la cámara", true);
            });

    private final ActivityResultLauncher<String[]> importLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) linkAndImportCatalog(uri);
            });

    private final ActivityResultLauncher<String[]> localImportLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) importLocalCatalog(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        scanTone = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);

        txtCatalogo = findViewById(R.id.txtCatalogo);
        txtEstado = findViewById(R.id.txtEstado);
        txtUnidades = findViewById(R.id.txtUnidades);
        txtSubtotal1 = findViewById(R.id.txtSubtotalLista1);
        txtSubtotal3 = findViewById(R.id.txtSubtotalLista3);
        txtTotal1 = findViewById(R.id.txtTotalLista1);
        txtTotal3 = findViewById(R.id.txtTotalLista3);
        txtSync = findViewById(R.id.txtSync);
        txtAhorroOfertas = findViewById(R.id.txtAhorroOfertas);
        edtBuscar = findViewById(R.id.edtBuscar);
        edtDescuento = findViewById(R.id.edtDescuentoFinal);
        scannerPanel = findViewById(R.id.scannerPanel);
        barcodeView = findViewById(R.id.barcodeView);

        RecyclerView recycler = findViewById(R.id.recyclerCarrito);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CartAdapter(this);
        recycler.setAdapter(adapter);

        Button btnEscanear = findViewById(R.id.btnEscanear);
        Button btnCatalogo = findViewById(R.id.btnImportar);
        Button btnBuscar = findViewById(R.id.btnBuscar);
        Button btnVaciar = findViewById(R.id.btnVaciar);
        Button btnCerrarScanner = findViewById(R.id.btnCerrarScanner);
        Button btnQuitarDescuento = findViewById(R.id.btnQuitarDescuento);

        btnEscanear.setOnClickListener(v -> startScanner());
        btnCerrarScanner.setOnClickListener(v -> hideInlineScanner());
        btnCatalogo.setOnClickListener(v -> showCatalogMenu());
        btnBuscar.setOnClickListener(v -> search(edtBuscar.getText().toString()));
        edtBuscar.setOnEditorActionListener((v, actionId, event) -> {
            search(edtBuscar.getText().toString());
            return true;
        });
        btnVaciar.setOnClickListener(v -> confirmClear());
        btnQuitarDescuento.setOnClickListener(v -> edtDescuento.setText("0"));

        edtDescuento.setText(prefs.getString(PREF_FINAL_DISCOUNT, "0"));
        edtDescuento.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                prefs.edit().putString(PREF_FINAL_DISCOUNT, s == null ? "0" : s.toString()).apply();
                refreshCart();
            }
        });

        barcodeView.decodeContinuous(new BarcodeCallback() {
            @Override public void barcodeResult(BarcodeResult result) {
                if (!scannerRunning || scannerBusy || result == null || result.getText() == null) return;
                String barcode = result.getText().trim();
                long now = System.currentTimeMillis();
                if (barcode.equals(lastScannedBarcode) && now - lastScanAt < 1800L) return;
                lastScannedBarcode = barcode;
                lastScanAt = now;
                scannerBusy = true;
                handleBarcode(barcode, () -> barcodeView.postDelayed(() -> scannerBusy = false, 650L));
            }
        });

        try {
            loadCatalog();
            loadCart();
            refreshCart();
            updateSyncLabel();
        } catch (Exception e) {
            showStatus("Error al cargar el catálogo: " + e.getMessage(), true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        autoSyncHandler.removeCallbacks(autoSyncRunnable);
        autoSyncHandler.postDelayed(autoSyncRunnable, 1200L);
        if (scannerRunning) barcodeView.resume();
    }

    @Override
    protected void onPause() {
        autoSyncHandler.removeCallbacks(autoSyncRunnable);
        if (barcodeView != null) barcodeView.pause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        autoSyncHandler.removeCallbacks(autoSyncRunnable);
        if (scanTone != null) {
            scanTone.release();
            scanTone = null;
        }
        super.onDestroy();
    }

    private void startScanner() {
        if (scannerRunning) {
            hideInlineScanner();
            return;
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            showInlineScanner();
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void showInlineScanner() {
        scannerPanel.setVisibility(View.VISIBLE);
        scannerRunning = true;
        scannerBusy = false;
        barcodeView.resume();
        showStatus("Escáner activo: apuntá al código. La pantalla permanece vertical.", false);
    }

    private void hideInlineScanner() {
        scannerRunning = false;
        scannerBusy = false;
        barcodeView.pause();
        scannerPanel.setVisibility(View.GONE);
    }

    private void handleBarcode(String barcode, Runnable onDone) {
        List<Product> matches = byBarcode.get(barcode);
        if (matches == null || matches.isEmpty()) {
            showStatus("Código de barras no encontrado: " + barcode, true);
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Artículo no encontrado")
                    .setMessage("No existe el código de barras " + barcode + " en el archivo de precios cargado.")
                    .setPositiveButton("Aceptar", null)
                    .create();
            dialog.setOnDismissListener(d -> onDone.run());
            dialog.show();
            return;
        }
        if (matches.size() == 1) {
            addProduct(matches.get(0));
            playScanBeep();
            onDone.run();
        } else {
            chooseProduct("Código repetido: " + barcode, matches, onDone, true);
        }
    }

    private void search(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) {
            Toast.makeText(this, "Ingresá un código o una descripción", Toast.LENGTH_SHORT).show();
            return;
        }

        Product exactCode = byCode.get(q);
        if (exactCode != null) {
            addProduct(exactCode);
            edtBuscar.setText("");
            return;
        }
        List<Product> exactBars = byBarcode.get(q);
        if (exactBars != null && !exactBars.isEmpty()) {
            if (exactBars.size() == 1) addProduct(exactBars.get(0));
            else chooseProduct("Código repetido: " + q, exactBars, () -> {}, false);
            edtBuscar.setText("");
            return;
        }

        String needle = q.toLowerCase(Locale.ROOT);
        List<Product> found = new ArrayList<>();
        for (Product p : byCode.values()) {
            if (p.descripcion.toLowerCase(Locale.ROOT).contains(needle)) {
                found.add(p);
                if (found.size() >= 40) break;
            }
        }
        if (found.isEmpty()) {
            showStatus("Sin resultados para: " + q, true);
        } else if (found.size() == 1) {
            addProduct(found.get(0));
            edtBuscar.setText("");
        } else {
            chooseProduct("Resultados para “" + q + "”", found, () -> {}, false);
        }
    }

    private void chooseProduct(String title, List<Product> products, Runnable onDone, boolean beepOnSelect) {
        String[] labels = new String[products.size()];
        for (int i = 0; i < products.size(); i++) {
            Product p = products.get(i);
            labels[i] = p.codigo + " - " + p.descripcion
                    + "\nL1 " + Money.format(p.lista1) + "   L3 " + Money.format(p.lista3)
                    + (p.tieneOferta() ? "\nOferta: " + p.etiquetaOferta() : "");
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(labels, (d, which) -> {
                    addProduct(products.get(which));
                    if (beepOnSelect) playScanBeep();
                    edtBuscar.setText("");
                })
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.setOnDismissListener(d -> onDone.run());
        dialog.show();
    }

    private void playScanBeep() {
        try {
            if (scanTone == null) {
                scanTone = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
            }
            scanTone.startTone(ToneGenerator.TONE_PROP_BEEP, 140);
        } catch (Exception ignored) {
            // El escaneo no debe fallar si el teléfono no puede reproducir el tono.
        }
    }

    private void addProduct(Product p) {
        cart.put(p.codigo, cart.getOrDefault(p.codigo, 0) + 1);
        saveCart();
        refreshCart();
        int cantidad = cart.getOrDefault(p.codigo, 0);
        String oferta = "";
        if (p.tieneOferta()) {
            oferta = p.ofertaActiva(cantidad)
                    ? " | OFERTA ACTIVA " + p.etiquetaOferta()
                    : " | Oferta " + p.etiquetaOferta() + " (faltan " + (p.ofertaCantidadMinima - cantidad) + ")";
        }
        showStatus("Agregado: " + p.descripcion + " | L1 " + Money.format(p.lista1)
                + " | L3 " + Money.format(p.lista3) + oferta, false);
    }

    @Override
    public void onDelta(Product product, int delta) {
        int value = cart.getOrDefault(product.codigo, 0) + delta;
        if (value <= 0) cart.remove(product.codigo);
        else cart.put(product.codigo, value);
        saveCart();
        refreshCart();
    }

    @Override
    public void onRemove(Product product) {
        cart.remove(product.codigo);
        saveCart();
        refreshCart();
    }

    private void refreshCart() {
        if (adapter == null || txtUnidades == null) return;
        List<CartAdapter.Row> rows = new ArrayList<>();
        int units = 0;
        int activeOffers = 0;
        BigDecimal subtotal1 = BigDecimal.ZERO;
        BigDecimal subtotal3 = BigDecimal.ZERO;
        BigDecimal savings1 = BigDecimal.ZERO;
        BigDecimal savings3 = BigDecimal.ZERO;
        boolean hasMissing1 = false;
        boolean hasMissing3 = false;

        for (Map.Entry<String, Integer> e : cart.entrySet()) {
            Product p = byCode.get(e.getKey());
            if (p == null) continue;
            int q = e.getValue();
            rows.add(new CartAdapter.Row(p, q));
            units += q;

            if (p.ofertaActiva(q)) activeOffers++;

            if (p.lista1 != null) {
                subtotal1 = subtotal1.add(calculateLineTotal(p, q, p.lista1));
                savings1 = savings1.add(p.ahorroOferta(p.lista1, q));
            } else {
                hasMissing1 = true;
            }

            if (p.lista3 != null) {
                subtotal3 = subtotal3.add(calculateLineTotal(p, q, p.lista3));
                savings3 = savings3.add(p.ahorroOferta(p.lista3, q));
            } else {
                hasMissing3 = true;
            }
        }
        Collections.reverse(rows);
        adapter.setRows(rows);

        BigDecimal discountPct = getFinalDiscountPercent();
        BigDecimal factor = BigDecimal.ONE.subtract(
                discountPct.divide(BigDecimal.valueOf(100), 8, RoundingMode.HALF_UP));
        BigDecimal final1 = subtotal1.multiply(factor);
        BigDecimal final3 = subtotal3.multiply(factor);

        txtUnidades.setText(units + (units == 1 ? " unidad" : " unidades")
                + " · " + rows.size() + " artículos distintos");
        txtSubtotal1.setText(Money.format(subtotal1) + (hasMissing1 ? " *" : ""));
        txtSubtotal3.setText(Money.format(subtotal3) + (hasMissing3 ? " *" : ""));
        txtTotal1.setText(Money.format(final1) + (hasMissing1 ? " *" : ""));
        txtTotal3.setText(Money.format(final3) + (hasMissing3 ? " *" : ""));

        if (txtAhorroOfertas != null) {
            if (activeOffers > 0) {
                txtAhorroOfertas.setVisibility(View.VISIBLE);
                txtAhorroOfertas.setText("Ofertas activas: " + activeOffers
                        + " · Ahorro L1 " + Money.format(savings1)
                        + " · L3 " + Money.format(savings3));
            } else {
                txtAhorroOfertas.setVisibility(View.GONE);
                txtAhorroOfertas.setText("");
            }
        }
    }

    private BigDecimal calculateLineTotal(Product p, int quantity, BigDecimal listPrice) {
        return p.totalLinea(listPrice, quantity);
    }

    private BigDecimal getFinalDiscountPercent() {
        if (edtDescuento == null) return BigDecimal.ZERO;
        String s = edtDescuento.getText() == null ? "" : edtDescuento.getText().toString().trim().replace(',', '.');
        try {
            BigDecimal v = new BigDecimal(s);
            if (v.compareTo(BigDecimal.ZERO) < 0) return BigDecimal.ZERO;
            if (v.compareTo(BigDecimal.valueOf(100)) > 0) return BigDecimal.valueOf(100);
            return v;
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    private void confirmClear() {
        if (cart.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Vaciar compra")
                .setMessage("¿Eliminar todos los artículos cargados?")
                .setPositiveButton("Vaciar", (d, w) -> {
                    cart.clear();
                    saveCart();
                    refreshCart();
                    showStatus("Compra vaciada", false);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showCatalogMenu() {
        boolean linked = prefs.contains(PREF_LINKED_URI);
        List<String> options = new ArrayList<>();
        options.add(linked ? "Cambiar archivo vinculado (Drive / Dropbox / local)" : "Vincular archivo (Drive / Dropbox / local)");
        if (linked) options.add("Sincronizar ahora");
        options.add("Importar una copia local sin vincular");
        if (linked) options.add("Desvincular archivo de nube");

        new AlertDialog.Builder(this)
                .setTitle("Catálogo de precios")
                .setItems(options.toArray(new String[0]), (dialog, which) -> {
                    String selected = options.get(which);
                    if (selected.startsWith("Vincular") || selected.startsWith("Cambiar")) {
                        importLauncher.launch(new String[]{"text/plain", "text/*", "application/octet-stream"});
                    } else if (selected.equals("Sincronizar ahora")) {
                        syncLinkedCatalog(true);
                    } else if (selected.startsWith("Importar una copia")) {
                        launchLocalImport();
                    } else if (selected.startsWith("Desvincular")) {
                        unlinkCloudCatalog();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void launchLocalImport() {
        localImportLauncher.launch(new String[]{"text/plain", "text/*", "application/octet-stream"});
    }

    private void importLocalCatalog(Uri uri) {
        String name = getDisplayName(uri);
        if (copyAndActivateCatalog(uri, name)) {
            showStatus("Copia local importada: " + name + ". No se modificó el vínculo de nube.", false);
        }
    }

    private void linkAndImportCatalog(Uri uri) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Algunos proveedores no implementan permiso persistente. Igual se intenta importar.
        }
        String name = getDisplayName(uri);
        prefs.edit()
                .putString(PREF_LINKED_URI, uri.toString())
                .putString(PREF_LINKED_NAME, name)
                .apply();
        if (copyAndActivateCatalog(uri, name)) {
            prefs.edit()
                    .putString(PREF_LINKED_SIGNATURE, getDocumentSignature(uri))
                    .putLong(PREF_LAST_SYNC, System.currentTimeMillis())
                    .apply();
            updateSyncLabel();
            showStatus("Catálogo vinculado y sincronizado: " + name, false);
        }
    }

    private void syncLinkedCatalog(boolean force) {
        if (syncing) return;
        String rawUri = prefs.getString(PREF_LINKED_URI, "");
        if (rawUri.isEmpty()) {
            if (force) showStatus("No hay un archivo de Drive/Dropbox vinculado", true);
            return;
        }
        Uri uri;
        try { uri = Uri.parse(rawUri); }
        catch (Exception e) { return; }

        String signature = getDocumentSignature(uri);
        String previous = prefs.getString(PREF_LINKED_SIGNATURE, "");
        if (!force && !signature.isEmpty() && signature.equals(previous)) {
            updateSyncLabel();
            return;
        }

        syncing = true;
        String name = prefs.getString(PREF_LINKED_NAME, getDisplayName(uri));
        boolean ok = copyAndActivateCatalog(uri, name);
        syncing = false;
        if (ok) {
            prefs.edit()
                    .putString(PREF_LINKED_SIGNATURE, signature)
                    .putLong(PREF_LAST_SYNC, System.currentTimeMillis())
                    .apply();
            updateSyncLabel();
            showStatus(force ? "Sincronización completada: " + name : "Catálogo actualizado automáticamente: " + name, false);
        } else if (force) {
            showStatus("No se pudo sincronizar el archivo vinculado", true);
        }
    }

    private boolean copyAndActivateCatalog(Uri uri, String displayName) {
        File temp = new File(getFilesDir(), TEMP_CATALOG);
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(temp)) {
            if (in == null) throw new Exception("No se pudo abrir el archivo");
            byte[] buffer = new byte[65536];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        } catch (Exception e) {
            showStatus("No se pudo leer el archivo: " + e.getMessage(), true);
            temp.delete();
            return false;
        }

        try {
            validateCatalog(temp);
            File internal = new File(getFilesDir(), INTERNAL_CATALOG);
            if (internal.exists() && !internal.delete()) throw new Exception("no se pudo reemplazar el catálogo anterior");
            if (!temp.renameTo(internal)) {
                try (InputStream in = new FileInputStream(temp); FileOutputStream out = new FileOutputStream(internal)) {
                    byte[] buffer = new byte[65536];
                    int n;
                    while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
                }
                temp.delete();
            }
            prefs.edit().putString(PREF_FILE_NAME, displayName).apply();
            loadCatalog();
            cart.entrySet().removeIf(e -> !byCode.containsKey(e.getKey()));
            saveCart();
            refreshCart();
            return true;
        } catch (Exception e) {
            temp.delete();
            showStatus("El TXT no tiene el formato esperado: " + e.getMessage(), true);
            return false;
        }
    }

    private void validateCatalog(File file) throws Exception {
        byte[] data;
        try (InputStream in = new FileInputStream(file)) { data = readAll(in); }
        String text = decodeText(data);
        String[] lines = text.split("\\r?\\n");
        int header = findHeader(lines);
        if (header < 0) throw new Exception("no se encontró el encabezado 'Rubro ... Barras'");
        int valid = 0;
        for (int i = header + 1; i < lines.length && valid < 5; i++) {
            String[] f = lines[i].split(";", -1);
            if (f.length >= 18 && !f[2].trim().isEmpty() && !f[3].trim().isEmpty()) valid++;
        }
        if (valid == 0) throw new Exception("no se encontraron artículos válidos");
    }

    private void unlinkCloudCatalog() {
        prefs.edit()
                .remove(PREF_LINKED_URI)
                .remove(PREF_LINKED_NAME)
                .remove(PREF_LINKED_SIGNATURE)
                .remove(PREF_LAST_SYNC)
                .apply();
        updateSyncLabel();
        showStatus("Archivo de nube desvinculado. Se conserva la última copia de precios.", false);
    }

    private String getDocumentSignature(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri,
                    new String[]{DocumentsContract.Document.COLUMN_LAST_MODIFIED, OpenableColumns.SIZE},
                    null, null, null);
            if (c != null && c.moveToFirst()) {
                long modified = c.isNull(0) ? 0L : c.getLong(0);
                long size = c.isNull(1) ? 0L : c.getLong(1);
                return modified + ":" + size;
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return "";
    }

    private void updateSyncLabel() {
        if (txtSync == null) return;
        String uri = prefs.getString(PREF_LINKED_URI, "");
        if (uri.isEmpty()) {
            txtSync.setText("Nube: no vinculada");
            return;
        }
        String name = prefs.getString(PREF_LINKED_NAME, "archivo vinculado");
        long last = prefs.getLong(PREF_LAST_SYNC, 0L);
        String when = last == 0L ? "pendiente" : new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(new Date(last));
        txtSync.setText("Nube: " + name + " · última sync " + when);
    }

    private String getDisplayName(Uri uri) {
        String name = "archivo importado";
        Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) {
            try {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx);
            } finally {
                c.close();
            }
        }
        return name;
    }

    private void loadCatalog() throws Exception {
        byCode.clear();
        byBarcode.clear();

        File internal = new File(getFilesDir(), INTERNAL_CATALOG);
        byte[] data;
        String sourceName;
        if (internal.exists()) {
            try (InputStream in = new FileInputStream(internal)) {
                data = readAll(in);
            }
            sourceName = prefs.getString(PREF_FILE_NAME, "TXT importado");
        } else {
            try (InputStream in = getAssets().open("precios.txt")) {
                data = readAll(in);
            }
            sourceName = "precios.txt incluido";
        }

        String text = decodeText(data);
        String[] lines = text.split("\\r?\\n");
        int header = findHeader(lines);
        if (header < 0) throw new Exception("no se encontró el encabezado 'Rubro ... Barras'");

        int skipped = 0;
        int withoutPrice = 0;
        int offers = 0;
        int invalidOffers = 0;
        for (int i = header + 1; i < lines.length; i++) {
            String line = lines[i];
            if (line.trim().isEmpty()) continue;
            String[] f = line.split(";", -1);
            if (f.length < 18) {
                skipped++;
                continue;
            }
            String code = f[2].trim();
            String desc = f[3].trim();
            BigDecimal l1 = parsePrice(f[4]);
            BigDecimal l3 = parsePrice(f[5]);
            String offer = f.length > 6 ? f[6].trim() : "";
            String bars = f[17].trim();
            if (code.isEmpty() || desc.isEmpty()) {
                skipped++;
                continue;
            }
            if (l1 == null || l3 == null) withoutPrice++;
            Product p = new Product(code, desc, l1, l3, bars, offer);
            if (p.tieneOferta()) offers++;
            if (p.ofertaInvalida) invalidOffers++;
            byCode.put(code, p);
            if (!bars.isEmpty()) byBarcode.computeIfAbsent(bars, k -> new ArrayList<>()).add(p);
        }

        int duplicatedBars = 0;
        for (List<Product> v : byBarcode.values()) if (v.size() > 1) duplicatedBars++;
        txtCatalogo.setText(sourceName + " · " + byCode.size() + " artículos");
        showStatus("Catálogo listo · " + byBarcode.size() + " códigos de barras · " + duplicatedBars + " códigos repetidos"
                + " · " + offers + " artículos con oferta"
                + (invalidOffers > 0 ? " · " + invalidOffers + " ofertas no reconocidas" : "")
                + (withoutPrice > 0 ? " · " + withoutPrice + " artículos con alguna lista sin precio" : "")
                + (skipped > 0 ? " · " + skipped + " líneas omitidas" : ""), false);
    }

    private int findHeader(String[] lines) {
        for (int i = 0; i < lines.length; i++) {
            if (lines[i].startsWith("Rubro") && lines[i].contains(";Barras")) return i;
        }
        return -1;
    }

    private BigDecimal parsePrice(String raw) {
        String s = raw == null ? "" : raw.trim();
        if (s.isEmpty() || s.replace("-", "").trim().isEmpty()) return null;
        s = s.replace(",", "").replace("$", "").trim();
        try {
            return new BigDecimal(s);
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[65536];
        int n;
        while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    private String decodeText(byte[] data) {
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data)).toString();
        } catch (CharacterCodingException e) {
            return new String(data, Charset.forName("windows-1252"));
        }
    }

    private void loadCart() {
        cart.clear();
        String raw = prefs.getString(PREF_CART, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String code = o.getString("code");
                int qty = o.getInt("qty");
                if (qty > 0 && byCode.containsKey(code)) cart.put(code, qty);
            }
        } catch (Exception ignored) {}
    }

    private void saveCart() {
        JSONArray arr = new JSONArray();
        try {
            for (Map.Entry<String, Integer> e : cart.entrySet()) {
                JSONObject o = new JSONObject();
                o.put("code", e.getKey());
                o.put("qty", e.getValue());
                arr.put(o);
            }
        } catch (Exception ignored) {}
        prefs.edit().putString(PREF_CART, arr.toString()).apply();
    }

    private void showStatus(String text, boolean error) {
        if (txtEstado == null) return;
        txtEstado.setText(text);
        txtEstado.setTextColor(getColor(error ? R.color.rojo : R.color.gris_texto));
    }
}
