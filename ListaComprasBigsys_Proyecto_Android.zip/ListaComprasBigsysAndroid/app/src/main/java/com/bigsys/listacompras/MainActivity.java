package com.bigsys.listacompras;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements CartAdapter.Listener {
    private static final String INTERNAL_CATALOG = "catalogo_bigsys.txt";
    private static final String PREFS = "lista_compras_prefs";
    private static final String PREF_CART = "cart_json";
    private static final String PREF_FILE_NAME = "catalog_name";

    private final Map<String, Product> byCode = new LinkedHashMap<>();
    private final Map<String, List<Product>> byBarcode = new LinkedHashMap<>();
    private final Map<String, Integer> cart = new LinkedHashMap<>();

    private TextView txtCatalogo, txtEstado, txtUnidades, txtTotal1, txtTotal3;
    private EditText edtBuscar;
    private CartAdapter adapter;
    private SharedPreferences prefs;

    private final ActivityResultLauncher<ScanOptions> barcodeLauncher =
            registerForActivityResult(new ScanContract(), result -> {
                if (result.getContents() != null) handleBarcode(result.getContents().trim());
            });

    private final ActivityResultLauncher<String[]> importLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) importCatalog(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        txtCatalogo = findViewById(R.id.txtCatalogo);
        txtEstado = findViewById(R.id.txtEstado);
        txtUnidades = findViewById(R.id.txtUnidades);
        txtTotal1 = findViewById(R.id.txtTotalLista1);
        txtTotal3 = findViewById(R.id.txtTotalLista3);
        edtBuscar = findViewById(R.id.edtBuscar);

        RecyclerView recycler = findViewById(R.id.recyclerCarrito);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CartAdapter(this);
        recycler.setAdapter(adapter);

        Button btnEscanear = findViewById(R.id.btnEscanear);
        Button btnImportar = findViewById(R.id.btnImportar);
        Button btnBuscar = findViewById(R.id.btnBuscar);
        Button btnVaciar = findViewById(R.id.btnVaciar);

        btnEscanear.setOnClickListener(v -> startScanner());
        btnImportar.setOnClickListener(v -> importLauncher.launch(new String[]{"text/plain", "text/*", "application/octet-stream"}));
        btnBuscar.setOnClickListener(v -> search(edtBuscar.getText().toString()));
        edtBuscar.setOnEditorActionListener((v, actionId, event) -> {
            search(edtBuscar.getText().toString());
            return true;
        });
        btnVaciar.setOnClickListener(v -> confirmClear());

        try {
            loadCatalog();
            loadCart();
            refreshCart();
        } catch (Exception e) {
            showStatus("Error al cargar el catálogo: " + e.getMessage(), true);
        }
    }

    private void startScanner() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("Apuntá la cámara al código de barras");
        options.setBeepEnabled(true);
        options.setOrientationLocked(false);
        options.setBarcodeImageEnabled(false);
        barcodeLauncher.launch(options);
    }

    private void handleBarcode(String barcode) {
        List<Product> matches = byBarcode.get(barcode);
        if (matches == null || matches.isEmpty()) {
            showStatus("Código de barras no encontrado: " + barcode, true);
            new AlertDialog.Builder(this)
                    .setTitle("Artículo no encontrado")
                    .setMessage("No existe el código de barras " + barcode + " en el archivo de precios cargado.")
                    .setPositiveButton("Aceptar", null)
                    .show();
            return;
        }
        if (matches.size() == 1) {
            addProduct(matches.get(0));
        } else {
            chooseProduct("Código repetido: " + barcode, matches);
        }
    }

    private void search(String raw) {
        String q = raw == null ? "" : raw.trim();
        if (q.isEmpty()) {
            Toast.makeText(this, "Ingresá un código o una descripción", Toast.LENGTH_SHORT).show();
            return;
        }

        Product exactCode = byCode.get(q);
        if (exactCode != null) {
            addProduct(exactCode);
            edtBuscar.setText("");
            return;
        }
        List<Product> exactBars = byBarcode.get(q);
        if (exactBars != null && !exactBars.isEmpty()) {
            if (exactBars.size() == 1) addProduct(exactBars.get(0));
            else chooseProduct("Código repetido: " + q, exactBars);
            edtBuscar.setText("");
            return;
        }

        String needle = q.toLowerCase(Locale.ROOT);
        List<Product> found = new ArrayList<>();
        for (Product p : byCode.values()) {
            if (p.descripcion.toLowerCase(Locale.ROOT).contains(needle)) {
                found.add(p);
                if (found.size() >= 40) break;
            }
        }
        if (found.isEmpty()) {
            showStatus("Sin resultados para: " + q, true);
        } else if (found.size() == 1) {
            addProduct(found.get(0));
            edtBuscar.setText("");
        } else {
            chooseProduct("Resultados para “" + q + "”", found);
        }
    }

    private void chooseProduct(String title, List<Product> products) {
        String[] labels = new String[products.size()];
        for (int i = 0; i < products.size(); i++) {
            Product p = products.get(i);
            labels[i] = p.codigo + " - " + p.descripcion + "\nL1 " + Money.format(p.lista1) + "   L3 " + Money.format(p.lista3);
        }
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(labels, (dialog, which) -> {
                    addProduct(products.get(which));
                    edtBuscar.setText("");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void addProduct(Product p) {
        cart.put(p.codigo, cart.getOrDefault(p.codigo, 0) + 1);
        saveCart();
        refreshCart();
        showStatus("Agregado: " + p.descripcion + " | L1 " + Money.format(p.lista1) + " | L3 " + Money.format(p.lista3), false);
    }

    @Override
    public void onDelta(Product product, int delta) {
        int value = cart.getOrDefault(product.codigo, 0) + delta;
        if (value <= 0) cart.remove(product.codigo);
        else cart.put(product.codigo, value);
        saveCart();
        refreshCart();
    }

    @Override
    public void onRemove(Product product) {
        cart.remove(product.codigo);
        saveCart();
        refreshCart();
    }

    private void refreshCart() {
        List<CartAdapter.Row> rows = new ArrayList<>();
        int units = 0;
        BigDecimal total1 = BigDecimal.ZERO;
        BigDecimal total3 = BigDecimal.ZERO;
        boolean hasMissing1 = false;
        boolean hasMissing3 = false;

        for (Map.Entry<String, Integer> e : cart.entrySet()) {
            Product p = byCode.get(e.getKey());
            if (p == null) continue;
            int q = e.getValue();
            rows.add(new CartAdapter.Row(p, q));
            units += q;
            if (p.lista1 != null) total1 = total1.add(p.lista1.multiply(BigDecimal.valueOf(q)));
            else hasMissing1 = true;
            if (p.lista3 != null) total3 = total3.add(p.lista3.multiply(BigDecimal.valueOf(q)));
            else hasMissing3 = true;
        }
        Collections.reverse(rows);
        adapter.setRows(rows);
        txtUnidades.setText(units + (units == 1 ? " unidad" : " unidades") + " · " + rows.size() + " artículos distintos");
        txtTotal1.setText(Money.format(total1) + (hasMissing1 ? " *" : ""));
        txtTotal3.setText(Money.format(total3) + (hasMissing3 ? " *" : ""));
    }

    private void confirmClear() {
        if (cart.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Vaciar compra")
                .setMessage("¿Eliminar todos los artículos cargados?")
                .setPositiveButton("Vaciar", (d, w) -> {
                    cart.clear();
                    saveCart();
                    refreshCart();
                    showStatus("Compra vaciada", false);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void importCatalog(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(new File(getFilesDir(), INTERNAL_CATALOG))) {
            if (in == null) throw new Exception("No se pudo abrir el archivo");
            byte[] buffer = new byte[65536];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        } catch (Exception e) {
            showStatus("No se pudo importar: " + e.getMessage(), true);
            return;
        }

        try {
            String display = getDisplayName(uri);
            prefs.edit().putString(PREF_FILE_NAME, display).apply();
            loadCatalog();
            cart.entrySet().removeIf(e -> !byCode.containsKey(e.getKey()));
            saveCart();
            refreshCart();
            showStatus("Archivo importado correctamente: " + display, false);
        } catch (Exception e) {
            showStatus("El TXT no tiene el formato esperado: " + e.getMessage(), true);
        }
    }

    private String getDisplayName(Uri uri) {
        String name = "archivo importado";
        Cursor c = getContentResolver().query(uri, null, null, null, null);
        if (c != null) {
            try {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && c.moveToFirst()) name = c.getString(idx);
            } finally {
                c.close();
            }
        }
        return name;
    }

    private void loadCatalog() throws Exception {
        byCode.clear();
        byBarcode.clear();

        File internal = new File(getFilesDir(), INTERNAL_CATALOG);
        byte[] data;
        String sourceName;
        if (internal.exists()) {
            try (InputStream in = new FileInputStream(internal)) {
                data = readAll(in);
            }
            sourceName = prefs.getString(PREF_FILE_NAME, "TXT importado");
        } else {
            try (InputStream in = getAssets().open("precios.txt")) {
                data = readAll(in);
            }
            sourceName = "precios.txt incluido";
        }

        String text = decodeText(data);
        String[] lines = text.split("\\r?\\n");
        int header = -1;
        for (int i = 0; i < lines.length; i++) {
            if (lines[i].startsWith("Rubro") && lines[i].contains(";Barras")) {
                header = i;
                break;
            }
        }
        if (header < 0) throw new Exception("no se encontró el encabezado 'Rubro ... Barras'");

        int skipped = 0;
        int withoutPrice = 0;
        for (int i = header + 1; i < lines.length; i++) {
            String line = lines[i];
            if (line.trim().isEmpty()) continue;
            String[] f = line.split(";", -1);
            if (f.length < 18) {
                skipped++;
                continue;
            }
            String code = f[2].trim();
            String desc = f[3].trim();
            BigDecimal l1 = parsePrice(f[4]);
            BigDecimal l3 = parsePrice(f[5]);
            String bars = f[17].trim();
            if (code.isEmpty() || desc.isEmpty()) {
                skipped++;
                continue;
            }
            if (l1 == null || l3 == null) withoutPrice++;
            Product p = new Product(code, desc, l1, l3, bars);
            byCode.put(code, p);
            if (!bars.isEmpty()) byBarcode.computeIfAbsent(bars, k -> new ArrayList<>()).add(p);
        }

        int duplicatedBars = 0;
        for (List<Product> v : byBarcode.values()) if (v.size() > 1) duplicatedBars++;
        txtCatalogo.setText(sourceName + " · " + byCode.size() + " artículos");
        showStatus("Catálogo listo · " + byBarcode.size() + " códigos de barras · " + duplicatedBars + " códigos repetidos" +
                (withoutPrice > 0 ? " · " + withoutPrice + " artículos con alguna lista sin precio" : "") +
                (skipped > 0 ? " · " + skipped + " líneas omitidas" : ""), false);
    }

    private BigDecimal parsePrice(String raw) {
        String s = raw == null ? "" : raw.trim();
        if (s.isEmpty() || s.replace("-", "").trim().isEmpty()) return null;
        s = s.replace(",", "").replace("$", "").trim();
        try {
            return new BigDecimal(s);
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[65536];
        int n;
        while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    private String decodeText(byte[] data) {
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data)).toString();
        } catch (CharacterCodingException e) {
            return new String(data, Charset.forName("windows-1252"));
        }
    }

    private void loadCart() {
        cart.clear();
        String raw = prefs.getString(PREF_CART, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String code = o.getString("code");
                int qty = o.getInt("qty");
                if (qty > 0 && byCode.containsKey(code)) cart.put(code, qty);
            }
        } catch (Exception ignored) {}
    }

    private void saveCart() {
        JSONArray arr = new JSONArray();
        try {
            for (Map.Entry<String, Integer> e : cart.entrySet()) {
                JSONObject o = new JSONObject();
                o.put("code", e.getKey());
                o.put("qty", e.getValue());
                arr.put(o);
            }
        } catch (Exception ignored) {}
        prefs.edit().putString(PREF_CART, arr.toString()).apply();
    }

    private void showStatus(String text, boolean error) {
        txtEstado.setText(text);
        txtEstado.setTextColor(getColor(error ? R.color.rojo : R.color.gris_texto));
    }
}
