package com.bigsys.listacompras;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class Money {
    private static final DecimalFormat FORMAT;
    static {
        DecimalFormatSymbols s = new DecimalFormatSymbols(new Locale("es", "AR"));
        s.setGroupingSeparator('.');
        s.setDecimalSeparator(',');
        FORMAT = new DecimalFormat("#,##0.000", s);
        FORMAT.setGroupingUsed(true);
    }

    private Money() {}

    public static synchronized String format(BigDecimal value) {
        if (value == null) return "Sin precio";
        return "$ " + FORMAT.format(value);
    }
}
