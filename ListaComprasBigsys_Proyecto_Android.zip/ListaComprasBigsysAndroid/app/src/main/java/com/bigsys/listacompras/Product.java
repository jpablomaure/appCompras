package com.bigsys.listacompras;

import java.math.BigDecimal;

public class Product {
    public final String codigo;
    public final String descripcion;
    public final BigDecimal lista1;
    public final BigDecimal lista3;
    public final String barras;

    public Product(String codigo, String descripcion, BigDecimal lista1, BigDecimal lista3, String barras) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.lista1 = lista1;
        this.lista3 = lista3;
        this.barras = barras;
    }
}
