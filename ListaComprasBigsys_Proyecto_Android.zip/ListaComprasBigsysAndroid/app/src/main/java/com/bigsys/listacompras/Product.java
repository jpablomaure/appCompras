package com.bigsys.listacompras;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Product {
    private static final Pattern OFFER_PATTERN = Pattern.compile(
            "^\\s*([0-9]+(?:[\\.,][0-9]+)?)\\s*%\\s*(?:x|por)\\s*([0-9]+)\\s*$",
            Pattern.CASE_INSENSITIVE);

    public final String codigo;
    public final String descripcion;
    public final BigDecimal lista1;
    public final BigDecimal lista3;
    public final String barras;
    public final String ofertaRaw;
    public final BigDecimal ofertaPorcentaje;
    public final int ofertaCantidadMinima;
    public final boolean ofertaInvalida;

    public Product(String codigo, String descripcion, BigDecimal lista1, BigDecimal lista3,
                   String barras, String ofertaRaw) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.lista1 = lista1;
        this.lista3 = lista3;
        this.barras = barras;
        this.ofertaRaw = ofertaRaw == null ? "" : ofertaRaw.trim();

        BigDecimal pct = null;
        int min = 0;
        boolean invalid = false;

        if (!isNoOffer(this.ofertaRaw)) {
            Matcher m = OFFER_PATTERN.matcher(this.ofertaRaw);
            if (m.matches()) {
                try {
                    pct = new BigDecimal(m.group(1).replace(',', '.'));
                    min = Integer.parseInt(m.group(2));
                    if (pct.compareTo(BigDecimal.ZERO) <= 0
                            || pct.compareTo(BigDecimal.valueOf(100)) > 0
                            || min < 1) {
                        pct = null;
                        min = 0;
                        invalid = true;
                    }
                } catch (Exception e) {
                    pct = null;
                    min = 0;
                    invalid = true;
                }
            } else {
                invalid = true;
            }
        }

        this.ofertaPorcentaje = pct;
        this.ofertaCantidadMinima = min;
        this.ofertaInvalida = invalid;
    }

    private static boolean isNoOffer(String raw) {
        if (raw == null) return true;
        String s = raw.trim();
        return s.isEmpty() || s.matches("-+");
    }

    public boolean tieneOferta() {
        return ofertaPorcentaje != null && ofertaCantidadMinima > 0;
    }

    public boolean ofertaActiva(int cantidad) {
        return tieneOferta() && cantidad >= ofertaCantidadMinima;
    }

    public String etiquetaOferta() {
        if (!tieneOferta()) return "";
        return ofertaPorcentaje.stripTrailingZeros().toPlainString() + "% x" + ofertaCantidadMinima;
    }

    public BigDecimal totalLinea(BigDecimal precioLista, int cantidad) {
        if (precioLista == null) return null;
        BigDecimal bruto = precioLista.multiply(BigDecimal.valueOf(cantidad));
        if (!ofertaActiva(cantidad)) return bruto;

        BigDecimal factor = BigDecimal.ONE.subtract(
                ofertaPorcentaje.divide(BigDecimal.valueOf(100), 8, RoundingMode.HALF_UP));
        return bruto.multiply(factor);
    }

    public BigDecimal ahorroOferta(BigDecimal precioLista, int cantidad) {
        if (precioLista == null || !ofertaActiva(cantidad)) return BigDecimal.ZERO;
        BigDecimal bruto = precioLista.multiply(BigDecimal.valueOf(cantidad));
        BigDecimal total = totalLinea(precioLista, cantidad);
        return total == null ? BigDecimal.ZERO : bruto.subtract(total);
    }
}
